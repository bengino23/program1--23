import java.util.Scanner;

public class CarCareChoice {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter a service (oil change, tire rotation, car wash): ");
        String service = input.nextLine();

        // input normalization
        service = service.trim().toLowerCase();

        switch (service) {
            case "oil change":
                System.out.println("Price: $25");
                break;
            case "tire rotation":
                System.out.println("Price: $22");
                break;
            case "car wash":
                System.out.println("Price: $10");
                break;
            default:
                System.out.println("Error: Service not recognized.");
        }

        input.close();
    }
}
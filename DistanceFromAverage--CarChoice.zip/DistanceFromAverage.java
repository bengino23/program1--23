import java.util.Scanner;

public class DistanceFromAverage {
    public static void main(String[] args) {
        final int MAX = 15;
        final double SENTINEL = 99999;

        Scanner input = new Scanner(System.in);
        double[] values = new double[MAX];

        int count = 0;
        double sum = 0;

        System.out.println("Enter up to 15 numbers (enter 99999 to stop):");

        while (count < MAX) {
            System.out.print("Enter value #" + (count + 1) + ": ");

            // basic input validation (must be a number)
            if (!input.hasNextDouble()) {
                System.out.println("Invalid input. Please enter a numeric value.");
                input.next(); // consume bad token
                continue;
            }

            double num = input.nextDouble();

            if (num == SENTINEL) {
                break; // sentinel stops input early
            }

            values[count] = num;
            sum += num;
            count++;
        }

        if (count == 0) {
            System.out.println("Error: No values were entered.");
            input.close();
            return;
        }

        double avg = sum / count;

        System.out.println("\nCount: " + count);
        System.out.printf("Average: %.2f%n", avg);
        System.out.println("Distances from average (value - avg):");

        for (int i = 0; i < count; i++) {
            double distance = values[i] - avg;
            System.out.printf("%.2f -> %+.2f%n", values[i], distance);
        }

        input.close();
    }
}
